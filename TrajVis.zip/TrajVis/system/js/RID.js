var RID;

var lat;
var lng;

var living_street;
var motorway;
var primary;
var residential;
var road;
var secondary;
var service;
var tertiary;
var trunk;
var unclassified;

var living_street_Set = new Set(living_street);
var motorway_Set = new Set(motorway);
var primary_Set = new Set(primary);
var residential_Set = new Set(residential);
var road_Set = new Set(road);
var secondary_Set = new Set(secondary);
var service_Set = new Set(service);
var tertiary_Set = new Set(tertiary);
var trunk_Set = new Set(trunk);
var unclassified_Set = new Set(unclassified);